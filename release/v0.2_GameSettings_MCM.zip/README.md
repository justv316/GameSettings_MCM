# Oblivion Remastered Comprehensive GameSettings MCM

# Changelog
0.1
* Release of the first batch of settings. 

## Description

* A Mod Configuration Menu (MCM) control panel for configuring every functional GameSetting in Oblivion Remastered. 
* Designed as a research project into Oblivion Remastered's GameSettings.
	* This project will continue to be updated as settings are checked to see if they are still functional in Oblivion Remastered.
* Currently there is no way to reflect the current settings in the MCM. Hopefully in the future we have a bit more control over what the MCM is displaying. 
	* The values displayed in the MCM are what is being set in INI file. When changed the MCM uses a Console Command to actually set the GameSetting.
	* Default GameSettings are not loaded when the MCM runs.

## Roadmap

1. Add support for the remaining ~300 GameSettings
2. Create documentation and support creating GameSetting profiles for Modders to easily distribute customized GameSetting profiles for their mods. 
3. Add Restore to Default method for all Managed GameSettings (This will require an esp)
	1. Currently, each setting has a 'Reset' button to return it back to its default value, but I will need to create a mechanism to reset all settings back to default for uninstallations, this will also help modders who use this as a resource to ensure their mods can be safely removed.

## Research

* If you want to participate in GameSettings research, please feel free to post comments on this Mod's page, send me a DM on Nexus, or if you know me on Discord through one of the many modding communities I am in, ping me there with whatever your findings are!

### Prerequisites
1. [UE4SS](https://www.nexusmods.com/oblivionremastered/mods/32)
	1. [Mad OBScript Extender v2.0a or Later](https://www.nexusmods.com/oblivionremastered/mods/4819)
	2. [Mad Config Menu MCM v3.6 or Later](https://www.nexusmods.com/oblivionremastered/mods/4810)
2. [OBSE](https://www.nexusmods.com/oblivionremastered/mods/282)
	1. [NL-Tag Remover](https://www.nexusmods.com/oblivionremastered/mods/473)
	
### Installation
0. Install Prerequisites
1. Copy Gameplay_GameSettings.ini to `\Oblivion Remastered\OblivionRemastered\Binaries\Win64\MadConfigs`

### Uninstallation
0. MCM Reset Method
	0. The uninstallation method needs to be written :D
	1. Currently, click the 'Reset' button next to any GameSettings you've changed before deleting the ini file 

### Usage
0. In-Game, press your assigned hotkey to open the MCM (Default: L)
1. Click on 'Gameplay_GameSettings' and configure your settings.

### Currently Supported Settings

**_Gameplay_GameSettings.ini_**

**Difficulty**

fDifficultyDamageTakenMultiplierNovice
fDifficultyDamageTakenMultiplierApprentice
fDifficultyDamageTakenMultiplierAdept
fDifficultyDamageTakenMultiplierJourneyman
fDifficultyDamageTakenMultiplierExpert
fDifficultyDamageTakenMultiplierMaster
fDifficultyDamageDealtMultiplierNovice
fDifficultyDamageDealtMultiplierApprentice
fDifficultyDamageDealtMultiplierAdept
fDifficultyDamageDealtMultiplierJourneyman
fDifficultyDamageDealtMultiplierExpert
fDifficultyDamageDealtMultiplierMaster

**Level Scaling**

iLevCreaLevelDifferenceMax
iLevItemLevelDifferenceMax
iLowLevelNPCMaxLevel

**Player World Interaction**

iMapMarkerRevealDistance
iMapMarkerVisibleDistance
iHoursToRespawnCell
iAllowRepairDuringCombat
iAllowRechargeDuringCombat
iAllowAlchemyDuringCombat
fPlayerDropDistance
fPlayerDeathReloadTime
iRemoveExcessDeadComplexCount
fRemoveExcessiveComplexDeadTime
iRemoveExcessDeadCount
fRemoveExcessiveDeadTime

**Actors**

iNumberActorsAllowedToFollowPlayer
iNumberActorsInCombatPlayer
iDeathDropWeaponChance
iFriendHitAllowed
iAllyHitAllowed
iActorLuckSkillBase
fActorLuckSkillMult
fActorStrengthEncumbranceMult
fActorSwimBreathBase
fActorSwimBreathMult
fActorSwimBreathDamage
iVampirismAgeOffset
fActorTeleportFadeSeconds
fActorAnimZAdjust


## Credits
1. Utilizes ObScript Extender created by [MadAborModding](https://next.nexusmods.com/profile/MadAborModding)
2. Utilizes MCM created by [MadAborModding](https://next.nexusmods.com/profile/MadAborModding)